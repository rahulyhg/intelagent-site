<?php
 // CUSTOM.PHP - Custom PHP block for personal customizations, activate it from WordPress menu > Apparence > Y Theme
?>